import java.io.Serializable;
import java.util.ArrayList;

public class Academics implements Serializable {
    ArrayList<Sem> sem;

    Academics()
    {
        sem = new ArrayList<Sem>();
    }

    public void addSemester()
    {
        Sem s = new Sem();
        s.addCourse();
        sem.add(s);
    }

}
