import java.io.Serializable;

public class InternalMarks implements Serializable {
    float mark;

    public InternalMarks()
    {
        mark=0;
    }

    public void calculate(FirstPeriodicalMarks fp, SecondPeriodicalMarks sp, ContinuousAssessmentMarks ca)
    {
        float f,s;
        f=(fp.getMark()/50)*15;
        s=(sp.getMark()/50)*15;

        mark=f+s+ca.getMark();
    }

    public float getMark()
    {
        return mark;
    }

    public String toString()
    {
        return "Internal Marks: "+ mark;
    }

    public void print()
    {
        System.out.println(toString());
    }


}
