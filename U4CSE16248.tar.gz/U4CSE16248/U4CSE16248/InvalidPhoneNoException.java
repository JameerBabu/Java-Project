public class InvalidPhoneNoException extends Exception {
	

	  InvalidPhoneNoException(){
		  super("Phone number should be 10 digits"); 

	  }
	}
