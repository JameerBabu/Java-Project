import java.io.*;
import java.util.Scanner;


public class Runner implements Serializable {

        public static void readFile() {
        try {
            FileInputStream f = new FileInputStream("Student.ser");
            ObjectInputStream o = new ObjectInputStream(f);
            StudentDiary st = (StudentDiary)o.readObject();
            st.displaydetails();
        }

        catch(FileNotFoundException fof) {
            System.out.println("File is not found!");
        }

        catch(IOException ioe) {
            System.out.println("may be corrupted!");
        }

        catch(ClassNotFoundException cnf) {
            System.out.println("Class is not found!");
        }

    }
    public static void writeFile(StudentDiary sd) {
        try {
            FileOutputStream f = new FileOutputStream("Student.ser");
            ObjectOutputStream o = new ObjectOutputStream(f);
            o.writeObject(sd);
        }

        catch(FileNotFoundException fof) {
            System.out.println("File is not found!");
        }

        catch(IOException ioe) {
            System.out.println(" may be corrupted!");
        }
    }

    public static void main(String args[]) {
        StudentDiary s = new StudentDiary();
        Scanner sc = new Scanner(System.in);
        int choice = 0;
        while (choice != 3) {
            System.out.println("press 1 to add details");
            System.out.println("press 2 to print details");
            System.out.println("press 3 to exit");
            choice = sc.nextInt();
            switch (choice) {
                case 1: {
                    s.addnewStudent();
                    writeFile(s);
                    break;
                }
                case 2: {
                    readFile();
                    break;
                }

                case 3:{
                    break;
                }
            }
        }
    }
}
