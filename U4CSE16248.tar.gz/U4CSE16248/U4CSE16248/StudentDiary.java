import java.io.Serializable;
import java.util.Scanner;

public class StudentDiary implements Serializable {
    Student st;
    Personal pers;
    Attendance att;
    Academics acc;
    


    StudentDiary()
    {
        st = new Student();
        pers = new Personal();
        att = new Attendance();
    acc = new Academics();
        
    }

    public void addnewStudent()
    {
        Scanner sc = new Scanner(System.in);
        int choice=0;
        while(choice!=10) {
            System.out.println("press 1 to add Student details");
            System.out.println("press 2 to add personal details");
            System.out.println("press 3 to add attendance");
            System.out.println("press 4 to add academic details");
            System.out.println("press 5 to exit");
            choice=sc.nextInt();

            switch(choice)
            {
                case 1:{
                    st.newStudent();
                    break;
                }

                case 2:{
                    pers.getPersonalData();
                    break;
                }

                case 3:{
                    att.addAttendance();
                    break;
                }

                case 4:{
                    System.out.println("your semester?");
                    int semm=sc.nextInt();
                    System.out.println("no of courses ?");
                    int k = sc.nextInt();
                    for(int i=0;i<k;i++) {
                        acc.addSemester();
                    }
                    break;
                }
                case 5:{
                    break;
                }
            }
        }
    }


    public void displaydetails()
    {
        st.printDetails();
        pers.displayData();
        att.print();
        
    }


}
